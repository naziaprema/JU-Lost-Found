# Deferred messaging UI

Messaging is temporarily excluded from the supervisor demonstration. No conversation,
account, report or image data has been deleted.

The original Java/form pairs for dashboard, Browse Reports, Matching Reports,
Account Data and Messages are preserved in ui-backup with .disabled extensions.
These are reference copies, outside src, and do not compile or open as GUI forms.
messages.form.parked is the actual form moved out of src.

To restore later:

1. Merge the messagesButton and claimButton components, layout entries and event
   handlers from the backed-up page pairs into the corresponding current pairs.
   Restore the original paired files directly only if no newer GUI changes need keeping.
2. Restore ui-backup/messages.form.disabled to src/lost/found/messages.form.
   Keep the current messages.java, which retains the implementation and the preview guard.
3. Set Features.MESSAGING_ENABLED to true. This re-enables the action helpers,
   message window and standalone launch, without changing any stored conversations.
4. Clean and Build, then run ClaimChecks and MatchContactChecks.

The active README describes the demonstration features. The prior full documentation
is preserved in ui-backup/README-before-demo.md.
